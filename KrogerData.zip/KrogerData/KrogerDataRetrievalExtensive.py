import json
import base64
import requests
import os

def get_oauth_token(client_id, client_secret):
    token_url = 'https://api-ce.kroger.com/v1/connect/oauth2/token'
    
    # Create base64 encoded string from client_id:client_secret
    credentials = f'{client_id}:{client_secret}'.encode()
    encoded_credentials = base64.b64encode(credentials).decode()
    
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': f'Basic {encoded_credentials}'
    }
    
    body = {
        'grant_type': 'client_credentials',
        'scope': 'product.compact'
    }
    
    response = requests.post(token_url, headers=headers, data=body)
    
    if response.status_code == 200:
        return response.json()['access_token']
    else:
        raise Exception(f"Failed to retrieve access token. Response: {response.text}")


def fetch_all_products(token, location_id, term): 
    url = f'https://api-ce.kroger.com/v1/products?filter.locationId={location_id}&filter.term={term}&filter.limit=50'
    headers = {
        'Authorization': f'Bearer {token}',
        'Accept': 'application/json'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch products for {term}. Status Code: {response.status_code}, Response: {response.text}")
    
    return response.json().get('data', [])


def save_to_json(data, filename):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)


if __name__ == '__main__':
    client_id = 'lookupproduct-243261243034246179535a3748364b505a5246386943346d796b73764f4c7866377643776b2f56376b4641474547434e66446c46444b30774c3272472768674105017895205'
    client_secret = 'EOWg2BcXeNxXCgvgr8zszjZCtVLOfRE2Aa0JkOzr'
    location_id = '01400376'  # Store ID you want to retrieve products from
    
    # Step 1: Get OAuth token
    token = get_oauth_token(client_id, client_secret)
    
    # Step 2: List of common grocery items
    grocery_items = [
        'Fruits', 'Vegetables', 'Fresh Herbs', 'Milk', 'Cheese', 'Yogurt', 'Eggs', 'Butter',
        'Beef', 'Chicken', 'Pork', 'Fish', 'Shellfish', 'Bread', 'Cakes', 'Pastries', 'Bagels',
        'Water', 'Soda', 'Juice', 'Tea', 'Coffee', 'Chips', 'Nuts', 'Cookies', 'Popcorn',
        'Soups', 'Beans', 'Canned Vegetables', 'Canned Fruits', 'Frozen Vegetables', 'Pizzas', 
        'Ice Cream', 'Frozen Dinners', 'Ketchup', 'Mustard', 'Salad Dressings', 'Spices', 
        'Rice', 'Pasta', 'Flour', 'Sugar', 'Grains', 'Asian Foods', 'Hispanic Foods', 
        'Indian Foods', 'Mediterranean Foods', 'Cereals', 'Oatmeal', 'Pancake Mixes', 
        'Organic Foods', 'Gluten-Free Foods', 'Vegan Foods', 'Keto Foods', 
        'Prescription Medications', 'Over-the-Counter Medicines', 'Shampoo', 'Soap', 
        'Deodorants', 'Oral Care', 'Multivitamins', 'Protein Powders', 'Herbal Supplements', 
        'Bandages', 'Antiseptics', 'Thermometers', 'Creams', 'Lotions', 'Cleansers', 
        'Lipsticks', 'Foundations', 'Mascara', 'Shampoos', 'Conditioners', 'Hair Dyes', 
        'Perfumes', 'Body Sprays', 'Deodorants', 'Detergents', 'Disinfectants', 'Sponges', 
        'Toilet Paper', 'Paper Towels', 'Napkins', 'Laundry Detergents', 'Fabric Softeners', 
        'Pots', 'Pans', 'Utensils', 'Cutlery', 'Tools', 'Screws', 'Nails', 'Paint', 
        'Seeds', 'Soil', 'Pots', 'Fertilizers', 'Chairs', 'Tables', 'Grills', 'Tents', 
        'Sleeping Bags', 'Coolers', 'Dog Food', 'Dog Toys', 'Leashes', 'Dog Beds', 
        'Cat Food', 'Cat Litter', 'Scratching Posts', 'Fish Food', 'Bird Food', 
        'Rodent Food', 'Fish Tanks', 'Filters', 'Plants', 'Men’s Shirts', 'Men’s Pants', 
        'Men’s Jackets', 'Men’s Underwear', 'Women’s Dresses', 'Women’s Tops', 
        'Women’s Skirts', 'Women’s Lingerie', 'Children’s T-shirts', 'Children’s Jeans', 
        'Children’s Pajamas', 'Children’s School Uniforms', 'Sneakers', 'Sandals', 'Boots', 
        'Hats', 'Gloves', 'Scarves', 'Belts', 'Phones', 'Chargers', 'Earbuds', 'Cables', 
        'Microwaves', 'Coffee Makers', 'Toasters', 'TVs', 'Game Consoles', 'Streaming Devices', 
        'Laptops', 'Printers', 'Stationery', 'Oils', 'Cleaners', 'Car Wax', 'Seat Covers', 
        'Floor Mats', 'Air Fresheners', 'Hammers', 'Saws', 'Screwdrivers', 'Sofas', 
        'Coffee Tables', 'Rugs', 'Beds', 'Mattresses', 'Dressers', 'Wall Art', 'Picture Frames', 
        'Lamps', 'Boxes', 'Organizers', 'Baskets', 'Car Seats', 'Strollers', 'Cribs', 
        'Disposable Diapers', 'Baby Wipes', 'Formula', 'Purees', 'Snacks for Babies', 
        'Educational Toys', 'Dolls', 'Action Figures', 'Board Games', 'Monopoly', 'Chess', 
        'Puzzles', 'Bikes', 'Scooters', 'Swings', 'Inflatable Pools', 'Snow Sleds', 
        'Christmas Decorations', 'Halloween Decorations', 'Easter Decorations', 'Notebooks', 
        'Backpacks', 'Pens', 'Yarn', 'Paint', 'Craft Kits', 'Weights', 'Yoga Mats', 
        'Resistance Bands', 'Workout Clothes', 'Workout Shoes', 'Baseballs', 'Basketballs', 
        'Tennis Rackets', 'Paper', 'Notebooks', 'Folders', 'Pens', 'Pencils', 'Markers', 
        'Paint', 'Brushes', 'Canvas', 'Fiction Books', 'Non-Fiction Books', 'Children’s Books', 
        'Magazines', 'Comics', 'DVDs', 'CDs', 'Vinyl Records'
        ]

    
    # Step 3: Fetch products and save each to a separate JSON file
    for item in grocery_items:
        print(f"Fetching data for '{item}'...")
        products = fetch_all_products(token, location_id, item)
        
        # Ensure the filename is valid and replace spaces with underscores
        filename = f"{item.replace(' ', '_')}.json"
        save_to_json(products, filename)
        
        print(f"Successfully saved {len(products)} products to {filename}")

