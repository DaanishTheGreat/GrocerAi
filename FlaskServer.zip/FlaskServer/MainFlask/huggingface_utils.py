import requests

API_URL = "https://api-inference.huggingface.co/models/tiiuae/falcon-7b-instruct"
headers = {"Authorization": "Bearer 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"}

def analyze_customer_input(input_text):
    prompt = f"Extract the necessary ingredients and supplies do not provide anything else (Only Provide List of items in comma only) for: {input_text}"
    data = {"inputs": prompt}

    response = requests.post(API_URL, headers=headers, json=data)

    if response.status_code != 200:
        raise Exception(f"Error with Hugging Face API: {response.status_code}, {response.text}")

    result = response.json()

    if isinstance(result, list) and len(result) > 0 and 'generated_text' in result[0]:
        return result[0]["generated_text"].split('\n')
    else:
        raise KeyError(f"Unexpected response format: {result}")

