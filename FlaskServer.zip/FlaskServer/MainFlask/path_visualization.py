import numpy as np
import cv2
from dijkstra import dijkstra_path
from faiss_utils import search_item_in_faiss

def generate_item_path_image(structured_list, faiss_index, metadata):
    items_to_find = []
    mapped_results = {}

    # Perform a FAISS search for each item in the structured list
    for item in structured_list:
        if item.strip():
            mapped_results[item.strip()] = search_item_in_faiss(item.strip(), faiss_index, metadata)
            # Collect items descriptions
            for result in mapped_results[item.strip()]:
                items_to_find.append(result['description'])

    # Load the product descriptions grid
    file_path = 'Finale.npy'
    product_descriptions = np.load(file_path, allow_pickle=True)

    # Find the coordinates of each item in the grid
    item_locations = {}
    for i in range(product_descriptions.shape[0]):
        for j in range(product_descriptions.shape[1]):
            # Check if the current cell contains any of the items
            cell = product_descriptions[i, j]
            for item in items_to_find:
                if len(cell) != 0:
                    if cell[0] != "floor":
                        if item in cell[1]:
                            print("Item in cell: ", item)
                            item_locations[item] = (i, j)

    # Ensure all items were found
    if len(item_locations) != len(items_to_find):
        print("Warning: Not All items found in grid")

    # Extract the locations in the order of the items to find
    ordered_item_locations = []
    for item in items_to_find:
        try:
            ordered_item_locations.append(item_locations[item])
        except:
            print("Error at", item)

    # Initialize the grid for Dijkstra's algorithm
    grid = np.array([[1 if cell == ['floor'] else 0 for cell in row] for row in product_descriptions], dtype=np.uint8)

    # Find paths for each consecutive pair of items and combine them
    full_path = []
    for i in range(len(ordered_item_locations) - 1):
        start = ordered_item_locations[i]
        end = ordered_item_locations[i + 1]
        partial_path = dijkstra_path(start, end, grid)
        if i > 0:  # To avoid duplicate coordinates
            partial_path = partial_path[1:]
        full_path.extend(partial_path)

    # Visualize the path using OpenCV
    path_image = cv2.cvtColor(grid * 255, cv2.COLOR_GRAY2BGR)

    # Draw the path
    for (x, y) in full_path:
        path_image[x, y] = (0, 0, 255)  # Red color for the path

    # Save the image with the path
    output_path = 'item_path_result.png'
    cv2.imwrite(output_path, path_image)

    # Return the path to the saved image
    return output_path

