from flask import request, jsonify
from faiss_utils import load_faiss_index_and_metadata, search_item_in_faiss
from huggingface_utils import analyze_customer_input
from kroger_data_utils import load_kroger_data, find_image_url
from path_visualization import generate_item_path_image

# Paths to FAISS index and metadata
faiss_index_path = '../../faiss_index.bin'
metadata_path = '../../metadata.json'
kroger_data_path = '../../KrogerData/'

# Load FAISS index, metadata, and Kroger data
faiss_index, metadata = load_faiss_index_and_metadata(faiss_index_path, metadata_path)
kroger_data = load_kroger_data(kroger_data_path)

def initialize_routes(app):

    @app.route('/api/getlist', methods=['POST'])
    def get_list():
        try:
            input_data = request.get_json()
            input_text = input_data.get('query', '')

            if not input_text:
                return jsonify({"error": "No query provided."}), 400

            structured_list = analyze_customer_input(input_text)
            mapped_results = {}
            for item in structured_list:
                if item.strip():
                    search_results = search_item_in_faiss(item.strip(), faiss_index, metadata)
                    for result in search_results:
                        result['image_url'] = find_image_url(result.get('description'), kroger_data)
                    mapped_results[item.strip()] = search_results

            return jsonify(mapped_results), 200

        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route('/api/getpath', methods=['POST'])
    def get_path():
        try:
            input_data = request.get_json()
            input_text = input_data.get('query', '')

            if not input_text:
                return jsonify({"error": "No query provided."}), 400

            structured_list = analyze_customer_input(input_text)
            item_path_image = generate_item_path_image(structured_list, faiss_index, metadata)

            return jsonify({"path_image": item_path_image}), 200

        except Exception as e:
            return jsonify({"error": str(e)}), 500

