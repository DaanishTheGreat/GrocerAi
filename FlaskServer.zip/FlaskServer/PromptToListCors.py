from flask import Flask, request, jsonify
from flask_cors import CORS
import faiss
import numpy as np
import json
import requests
from sentence_transformers import SentenceTransformer

# Initialize Flask application
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Hugging Face API endpoint and token
API_URL = "https://api-inference.huggingface.co/models/tiiuae/falcon-7b-instruct"
headers = {"Authorization": "Bearer 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"}  # Replace with your Hugging Face token

# Load local model for embeddings
model = SentenceTransformer('all-mpnet-base-v2')

# Load FAISS index and metadata
faiss_index_path = '../faiss_index.bin'  # Path to the saved FAISS index
metadata_path = '../metadata.json'  # Path to the saved metadata
faiss_index, metadata = None, None

def load_faiss_index_and_metadata(faiss_index_path, metadata_path):
    global faiss_index, metadata
    faiss_index = faiss.read_index(faiss_index_path)
    with open(metadata_path, 'r') as f:
        metadata = json.load(f)

# Function to get local embeddings using the new model
def get_local_embedding(text):
    return model.encode(text).tolist()

# Function to call Hugging Face API for text generation
def analyze_customer_input(input_text):
    prompt = f"Extract the necessary ingredients and supplies do not provide anything else (Only Provide List of items in comma only) for: {input_text}"
    data = {"inputs": prompt}

    # Make the request to Hugging Face API
    response = requests.post(API_URL, headers=headers, json=data)

    # Check if the response status is OK (200)
    if response.status_code != 200:
        raise Exception(f"Error with Hugging Face API: {response.status_code}, {response.text}")

    # Parse the JSON response
    result = response.json()

    # Ensure the response contains the expected 'generated_text' field
    if isinstance(result, list) and len(result) > 0 and 'generated_text' in result[0]:
        # Return the list of ingredients extracted
        ResultVal = result[0]["generated_text"].split('\n')
        print("Data Split: " + str(ResultVal))
        return ResultVal
    else:
        raise KeyError(f"Unexpected response format: {result}")

# Function to search for items in FAISS based on each list item
def search_item_in_faiss(item, faiss_index, metadata, k=1):
    query_embedding = model.encode([item])  # Get embedding of the individual list item
    query_embedding = np.array(query_embedding)  # Ensure correct shape
    distances, indices = faiss_index.search(query_embedding, k=k)  # Search top k items
    return [metadata[i] for i in indices[0]]  # Return the closest matching item

# Flask route to handle the /api/getlist POST request
@app.route('/api/getlist', methods=['POST'])
def get_list():
    try:
        # Get input text from the request JSON body
        input_data = request.get_json()
        input_text = input_data.get('query', '')

        if not input_text:
            return jsonify({"error": "No query provided."}), 400

        # Step 1: Analyze input using Hugging Face API to extract structured request (list of items)
        structured_list = analyze_customer_input(input_text)
        print(f"Structured List: {structured_list}")

        # Step 2: Perform a FAISS search for each item in the structured list
        mapped_results = {}
        for item in structured_list:
            if item.strip():  # Avoid empty strings
                mapped_results[item.strip()] = search_item_in_faiss(item.strip(), faiss_index, metadata)

        # Step 3: Return the results as JSON
        return jsonify(mapped_results), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Load FAISS index and metadata when starting the Flask app
load_faiss_index_and_metadata(faiss_index_path, metadata_path)

# Entry point for running the Flask app
if __name__ == '__main__':
    # Run the app on host 0.0.0.0 to make it publicly accessible
    app.run(host='0.0.0.0', port=80)  # Use a higher port for non-root


