import faiss
import numpy as np
import json
from sentence_transformers import SentenceTransformer

# Load local model for embeddings
model = SentenceTransformer('all-mpnet-base-v2')

def load_faiss_index_and_metadata(faiss_index_path, metadata_path):
    faiss_index = faiss.read_index(faiss_index_path)
    with open(metadata_path, 'r') as f:
        metadata = json.load(f)
    return faiss_index, metadata

def search_item_in_faiss(item, faiss_index, metadata, k=1):
    query_embedding = model.encode([item])
    query_embedding = np.array(query_embedding)
    distances, indices = faiss_index.search(query_embedding, k=k)
    return [metadata[i] for i in indices[0]]

