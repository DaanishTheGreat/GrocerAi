import numpy as np
import cv2
import os
import random
from dijkstra import dijkstra_path
from faiss_utils import search_item_in_faiss

def generate_item_path_image(structured_list, faiss_index, metadata):
    try:
        items_to_find = []
        mapped_results = {}

        # Debug: Print the received structured list
        print(f"Received structured list in generate_item_path_image: {structured_list}")

        # Perform a FAISS search for each item in the structured list
        for item in structured_list:
            if item.strip():
                # Debug: Print the item being processed
                print(f"Processing item: {item}")
                mapped_results[item.strip()] = search_item_in_faiss(item.strip(), faiss_index, metadata)

                # Collect items descriptions
                for result in mapped_results[item.strip()]:
                    print(f"Found description: {result['description']}")
                    items_to_find.append(result['description'])

        # Debug: Print the items to find
        print(f"Items to find: {items_to_find}")

        # Load the product descriptions grid
        file_path = 'Finale.npy'
        if not os.path.exists(file_path):
            print(f"Error: {file_path} not found.")
            raise FileNotFoundError(f"{file_path} not found.")

        product_descriptions = np.load(file_path, allow_pickle=True)

        # Find the coordinates of each item in the grid
        item_locations = {}
        for i in range(product_descriptions.shape[0]):
            for j in range(product_descriptions.shape[1]):
                # Check if the current cell contains any of the items
                cell = product_descriptions[i, j]
                for item in items_to_find:
                    if len(cell) != 0:
                        if cell[0] != "floor":
                            if item in cell[1]:
                                print(f"Item '{item}' found in cell: ({i}, {j})")
                                item_locations[item] = (i, j)

        # Ensure all items were found
        if len(item_locations) != len(items_to_find):
            print("Warning: Not all items found in grid")
            print(f"Expected items: {len(items_to_find)}, Found: {len(item_locations)}")

        # Add the start and end points
        start_point = (107, 176)
        end_point = (95, 152)
        ordered_item_locations = [start_point]

        # Apply Nearest Neighbor heuristic to find the optimal order for the middle points
        unvisited = set(item_locations.values())

        if start_point in unvisited:
            unvisited.remove(start_point)
        if end_point in unvisited:
            unvisited.remove(end_point)

        current_point = start_point
        while unvisited:
            # Find the nearest unvisited point
            next_point = min(unvisited, key=lambda point: np.linalg.norm(np.array(current_point) - np.array(point)))
            ordered_item_locations.append(next_point)
            current_point = next_point
            unvisited.remove(next_point)

        # Finally, add the end point
        ordered_item_locations.append(end_point)

        # Debug: Print ordered item locations
        print(f"Ordered item locations: {ordered_item_locations}")

        # Initialize the grid for Dijkstra's algorithm
        grid = np.array([[1 if cell == ['floor'] else 0 for cell in row] for row in product_descriptions], dtype=np.uint8)

        # Find paths for each consecutive pair of items and combine them
        full_path = []
        path_segments = []  # To store path segments for different colors
        colors = []  # To store random colors for each path segment
        legend_entries = []  # To store legend text
        segment_items = []  # To store item names for the legend

        # Prepare a list of items names for the legend
        item_names = ["Start"] + [item for item, location in item_locations.items() if location in ordered_item_locations] + ["End"]

        for i in range(len(ordered_item_locations) - 1):
            start = ordered_item_locations[i]
            end = ordered_item_locations[i + 1]
            print(f"Finding path from {start} to {end}")

            # Attempt to find the path
            try:
                partial_path = dijkstra_path(start, end, grid)
                if len(partial_path) < 2:
                    print(f"Warning: Disjointed path from {start} to {end}")
                    continue  # Skip adding disjointed paths
            except Exception as e:
                print(f"Error finding path from {start} to {end}: {str(e)}")
                continue  # Skip if no valid path is found

            if i > 0:  # To avoid duplicate coordinates
                partial_path = partial_path[1:]

            full_path.extend(partial_path)
            path_segments.append(partial_path)  # Save path segments separately

            # Generate a random color for this segment
            color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
            colors.append(color)

            # Add a legend entry
            if i == 0:
                legend_entries.append(f"{item_names[0]} to {item_names[1]}")
            elif i == len(ordered_item_locations) - 2:
                legend_entries.append(f"{item_names[i]} to {item_names[-1]}")
            else:
                legend_entries.append(f"{item_names[i]} to {item_names[i+1]}")

        # Visualize the path using OpenCV
        path_image = cv2.cvtColor(grid * 255, cv2.COLOR_GRAY2BGR)

        # Draw the path segments with random colors
        for segment_idx, segment in enumerate(path_segments):
            color = colors[segment_idx]  # Get the random color for this segment
            for (x, y) in segment:
                # Draw using (x, y) coordinates
                path_image[x, y] = color

        # Increase the size of the image for better visualization
        scale_factor = 3  # Adjust the scale factor as needed for clarity
        path_image = cv2.resize(path_image, (0, 0), fx=scale_factor, fy=scale_factor, interpolation=cv2.INTER_NEAREST)

        # Draw the legend on the right side of the image
        legend_x = path_image.shape[1] + 20
        legend_y = 20
        legend_image_height = max(path_image.shape[0], (len(legend_entries) + 1) * 30)
        legend_image = np.ones((legend_image_height, legend_x + 200, 3), dtype=np.uint8) * 255

        # Copy the path image onto the legend image
        legend_image[0:path_image.shape[0], 0:path_image.shape[1]] = path_image

        # Draw legend entries
        for idx, (text, color) in enumerate(zip(legend_entries, colors)):
            cv2.putText(legend_image, text, (legend_x, legend_y + idx * 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1)
            cv2.rectangle(legend_image, (legend_x - 20, legend_y - 10 + idx * 30), (legend_x - 5, legend_y + 10 + idx * 30), color, -1)

        # Directory to save images
        output_dir = 'static/images'
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Save the image with the path and legend
        output_path = os.path.join(output_dir, 'item_path_result.png')
        cv2.imwrite(output_path, legend_image)

        print(f"Image successfully saved to {output_path}")

        # Return the path to the saved image
        return output_path

    except Exception as e:
        print(f"Error in generate_item_path_image: {str(e)}")
        raise
