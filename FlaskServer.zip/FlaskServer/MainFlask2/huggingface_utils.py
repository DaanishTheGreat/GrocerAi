import requests

# OpenAI chat completion endpoint for chat models
API_URL = "https://api.openai.com/v1/chat/completions"
headers = {
    "Authorization": "Bearer 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",
    "Content-Type": "application/json"
}

def analyze_customer_input(input_text):
    prompt = f"Extract the necessary ingredients and supplies and estimated calorie if applicable, do not provide anything else (Only Provide List of items in each new line with the format: Item Name, calorie) for: {input_text}"
    
    # OpenAI chat model expects 'messages' instead of 'prompt'
    data = {
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ],
        "max_tokens": 150,  # Adjust as needed
        "temperature": 0.7  # Adjust as needed for creativity
    }

    response = requests.post(API_URL, headers=headers, json=data)

    if response.status_code != 200:
        raise Exception(f"Error with OpenAI API: {response.status_code}, {response.text}")

    result = response.json()
    
    # OpenAI returns a 'choices' list; get the 'message' text from the first choice
    if "choices" in result and len(result["choices"]) > 0:
        return result["choices"][0]["message"]["content"].strip().split('\n')
    else:
        raise KeyError(f"Unexpected response format: {result}")

# Example usage:
input_text = "I want to make biryani"
print(analyze_customer_input(input_text))

