import os
import json

def load_kroger_data(kroger_data_path):
    kroger_data = []
    for filename in os.listdir(kroger_data_path):
        if filename.endswith('.json'):
            file_path = os.path.join(kroger_data_path, filename)
            with open(file_path, 'r') as f:
                data = json.load(f)
                kroger_data.extend(data)
    return kroger_data

def find_image_url(description, kroger_data):
    for product in kroger_data:
        if product['description'] == description:
            for image_info in product.get('images', []):
                for size_info in image_info.get('sizes', []):
                    if size_info['size'] == 'xlarge':
                        return size_info['url']
                    elif size_info.get('url'):
                        return size_info['url']
    return None

