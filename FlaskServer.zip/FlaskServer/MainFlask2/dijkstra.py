import numpy as np

def dijkstra_path(start_point, end_point, grid):
    # Initialize the cost and path matrices
    cost = np.full(grid.shape, np.inf)
    cost[start_point] = 0
    previous_node = np.full(grid.shape + (2,), -1, dtype=int)

    # Directions for moving in the grid (up, down, left, right)
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    # Dijkstra's algorithm using a priority queue (implemented using a list)
    unvisited = [(0, start_point)]

    while unvisited:
        # Pop the node with the smallest cost
        current_cost, current_node = min(unvisited, key=lambda x: x[0])
        unvisited.remove((current_cost, current_node))
        
        x, y = current_node

        # If we reached the end point, break
        if current_node == end_point:
            break

        # Explore neighbors
        for direction in directions:
            nx, ny = x + direction[0], y + direction[1]
            
            # Check bounds and if it's a walkable area
            if 0 <= nx < grid.shape[0] and 0 <= ny < grid.shape[1] and grid[nx, ny] == 1:
                new_cost = current_cost + 1  # Distance between nodes is 1
                
                # If a cheaper path is found
                if new_cost < cost[nx, ny]:
                    cost[nx, ny] = new_cost
                    previous_node[nx, ny] = [x, y]
                    unvisited.append((new_cost, (nx, ny)))

    # Backtrack to find the path
    path = []
    node = end_point
    while node != start_point:
        path.append(node)
        node = tuple(previous_node[node[0], node[1]])
    path.append(start_point)
    path.reverse()

    return path

