
from flask import request, jsonify, send_file
from faiss_utils import load_faiss_index_and_metadata, search_item_in_faiss
from huggingface_utils import analyze_customer_input
from kroger_data_utils import load_kroger_data, find_image_url
from path_visualization import generate_item_path_image
import os

# Paths to FAISS index and metadata
faiss_index_path = '../../faiss_index.bin'
metadata_path = '../../metadata.json'
kroger_data_path = '../../KrogerData/'

# Load FAISS index, metadata, and Kroger data
faiss_index, metadata = load_faiss_index_and_metadata(faiss_index_path, metadata_path)
kroger_data = load_kroger_data(kroger_data_path)

def initialize_routes(app):

    @app.route('/api/getlist', methods=['POST'])
    def get_list():
        try:
            input_data = request.get_json()
            input_text = input_data.get('query', '')

            # Debug: Print the received input
            print(f"Received input for /api/getlist: {input_text}")

            if not input_text:
                return jsonify({"error": "No query provided."}), 400

            structured_list = analyze_customer_input(input_text)
            # Debug: Print the structured list
            print(f"Structured list: {structured_list}")

            mapped_results = {}
            for item in structured_list:
                if item.strip():
                    search_results = search_item_in_faiss(item.strip(), faiss_index, metadata)
                    for result in search_results:
                        result['image_url'] = find_image_url(result.get('description'), kroger_data)
                    mapped_results[item.strip()] = search_results

            # Debug: Print the mapped results
            print(f"Mapped results: {mapped_results}")

            return jsonify(mapped_results), 200

        except Exception as e:
            # Print the error to the console for debugging
            print(f"Error occurred in /api/getlist: {str(e)}")
            return jsonify({"error": str(e)}), 500

    @app.route('/api/getpath', methods=['POST'])
    def get_path():
        try:
            input_data = request.get_json()

            # Extract the descriptions from the received JSON
            descriptions = input_data.get('descriptions', [])

            # Debug: Print the received descriptions
            print(f"Received descriptions for /api/getpath: {descriptions}")

            if not descriptions:
                return jsonify({"error": "No descriptions provided."}), 400

            # Use the descriptions directly for generating the path
            item_path_image = generate_item_path_image(descriptions, faiss_index, metadata)

            # Check if the image file was generated and saved successfully
            if os.path.exists(item_path_image):
                # Send the PNG image file to the frontend
                return send_file(item_path_image, mimetype='image/png')
            else:
                print("Error: Image file was not generated.")
                return jsonify({"error": "Failed to generate image"}), 500

        except Exception as e:
            # Print the error to the console for debugging
            print(f"Error occurred in /api/getpath: {str(e)}")
            return jsonify({"error": str(e)}), 500

